# Code Snippets
```javascript
console.log('Hello, world!');