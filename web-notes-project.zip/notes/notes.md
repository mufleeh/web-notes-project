# Notes
Here are some notes about the project.